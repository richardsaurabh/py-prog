__ChatTTS x OpenVoice__

Enhance the authenticity of speech by utilizing ChatTTS for more natural voice generation, complemented with the voice timber simulation module from Openvoice for seamless tone transplantation.

Have a try on huggingface!
https://huggingface.co/spaces/Hilley/ChatTTS-OpenVoice

<img width="1792" alt="image" src="https://github.com/HKoon/ChatTTS-OpenVoice/assets/24382626/9d9592f1-b527-4c7a-b7f8-caf2cd25bc1d">

